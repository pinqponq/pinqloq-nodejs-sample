# Changelog

All notable changes to the `pinqloq` npm package are documented here. This package follows
[Semantic Versioning](https://semver.org). Its version numbers are independent of the .NET
`pinqloq` NuGet package (`sdk/ClientLogs.Client/`) — the two ship on separate cadences for the
same platform, and mirror each other's feature set rather than their version numbers.

## 1.0.0 — 2026-09-04

**Added:**

- Initial release: feature parity with the .NET SDK's core surface.
- `createPinqloq(options)` — buffered, batched manual structured logging (`logger.enqueue` /
  `logger.enqueueMany`), delivered to the same `/bulk` ingest endpoint the .NET SDK uses.
- `client.requestLogging(options)` — Express middleware for automatic HTTP request/response
  logging: captures method/path/status/duration, request/response bodies (32KB cap) and headers,
  resolves `deviceIdentifier` (selector → `device-identifier` header → global fallback, HTTP 400
  if none resolve) and `correlationId` (`correlation-id` header → generated id).
- Redaction: a built-in, unconditional credential-name floor (password, token, Authorization,
  ...) plus `redactFields` (name-based, any nesting depth) and `redactPaths` (whole-body/header
  masking, the `[PinqloqRedactEndpoint]` equivalent). Fails closed on a sensitive body that can't
  be parsed as JSON, matching the .NET SDK's behavior.
